#streamlit 추가 및 약어 st로 정하기
import streamlit as st
#glob 가져오기
from glob import glob

#동의 했을때만 설문조사가 나오도록 변수 만들기
Personal_Information_Consent_Form=False
Accept_the_terms_and_conditions=False
#자녀가 있을때만 설문조사가 나오도록 변수 만들기
kid=False

#개인정보 동의서,약관동의 둘중 하나라도 확인하지 않는다면 설문조사를 할수 없다.
checkbox_btn = st.checkbox("개인정보 동의서(필수)")
if checkbox_btn:
    Personal_Information_Consent_Form=True

checkbox_btn2 = st.checkbox("약관 동의(필수)")
if checkbox_btn2:
    Accept_the_terms_and_conditions=True

#설문조사 시작

#만약 동의 안한것이 있을경우 설문조사가 나오지 않는다.
if Personal_Information_Consent_Form==True and Accept_the_terms_and_conditions==True:
#성별
    selected_item = st.radio("성별", ("남성", "여성", "공개안함"))
#국적
    option = st.selectbox("국적", ("내국인","외국인"))
#나이
    values = st.slider('당신의 나이', 0, 100)
#자녀 유무
    option2 = st.selectbox("자녀가 있나요?", ("없다", "있다"))
#있을경우
    if option2 == "있다":
        kid = True

    if kid==True:
#자녀의 성별
        option3 = st.selectbox("(자녀가 있을경우)성별",("남성", "여성", "둘다"))
#자녀 수
        values2 = st.slider('(자녀가 있을경우)자녀 수', 0, 10)
#좋아하는 노래 장르
    multi_option = st.multiselect("좋아하는 노래장르",("락","팝송","클래식","재즈","블루스","R&B","디스코","댄스","EDM","트로트"))
#좋아하는 게임장르
    multi_option2 = st.multiselect("좋아하는 게임장르 =",("AR","P2E","게임 플랫폼","기능성","레이싱","롤플레잉","리듬","마피아","멀티플레이 전용","메트로배니아","방치형","배틀로얄","버라이어티","보드 게임","비대칭 PvP","샌드박스","소셜","소재별","수집형","슈팅","스포트","시뮬레이션","액션","어드벤처","오픈 월드","음악","이미테이션","인디","인터랙티브 무비","체감형","퀴즈","타일매칭","탄막","탑뷰","턴제","테이블","토너먼트","퍼즐","포격","하이퍼 캐주얼"))
#민초단 확인
    checkbox_btn3 = st.checkbox("혹시 민트초코 좋아하세요?")
    if checkbox_btn3:
        st.write("당신은 치약을 초콜릿과 같이 먹는걸 좋아한다...메모")
#제출버튼
    if st.button("제출"):
        files = glob("*.txt")
        f = open("{}.txt".format(str(len(files) + 1)), "w")
        f.write("모두 동의했습니다\n")
        f.write("Q1.성별 : {} \n".format(selected_item))
        f.write("Q2.국적 : {} \n".format(option))
        f.write("Q3.나이 : {} \n".format(values))
        f.write("Q4.자녀 : {} \n".format(option2))
        if kid == True:
            f.write("Q4(자녀가 있을경우).성별 : {} \n".format(option3))
            f.write("Q4(자녀가 있을경우).자녀 수 : {} \n".format(values2))
        f.write("Q5.좋아하는 노래장르 : {} \n".format(multi_option))
        f.write("Q5.좋아하는 게임장르 : {} \n".format(multi_option2))
        if checkbox_btn3:
            f.write("Q6.혹시 민트초코 좋아하세요? : 좋다 \n")
        else:
            f.write("Q6.혹시 민트초코 좋아하세요? : 싫다 \n")
        f.close()
@st.cache
def load_data():
    pass