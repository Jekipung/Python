#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma warning(disable:4996)

char str[20];

typedef struct stack {
    struct node* top;
}Stack;

typedef struct node {
    char data;
    struct node* next;
}Node;

void init(Stack* ps) {
    ps -> top = NULL;
}

int isEmpty(Stack* ps) {
    if(ps->top == NULL) {
        return 1;
    }
    else
        return 0;
}

void push(Stack* ps, char d) {
    Node* newNode = malloc(sizeof(Node));
    newNode->data = d;
    newNode->next = ps->top;
    ps->top = newNode;
}

char pop(Stack* ps) {
    char rdata;
    Node* rnode;

    if (isEmpty(ps)) {
        printf("stack memory error");
        exit(-1);
    } 

    rdata = ps -> top -> data;
    rnode = ps -> top;
    
    ps -> top = ps -> top -> next;
    free(rnode);

    return rdata;
}


int main() {
    printf("문자열 입력: ");
    scanf("%[^\n]s",str);
    Stack S1;
    for (int i = 0; i < strlen(str); i++) {
        push(&S1, str[i]);
    }

    int i;
    for (i = 0; i < strlen(str); i++) {
        str[i] = pop(&S1);
    }
    str[i] = '\0';

    printf("%s", str);

    return 0;
}