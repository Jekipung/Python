window.addEventListener('load', function() {
    // querySelector는 getElement~ 처럼 HTML 요소를 가져올떄 사용한다.
    // id값으러 가져오는 경우     : #id
    // tag값으로 가져오는 경우    : 태그명
    // class로 가져오는 경우      : .class
    // 기타 속성으로 가져오는 경우 : [속성명 = 속성값]
    let canvas = document.querySelector('#myCanvas')
    // 그림을 그리기 위한 환경을 가져옴
    let ctx = canvas.getContext('2d');

    // 죄표 (50, 60) 의 위치에 너비 200 높이 100 짜리 사각형 그리기
    ctx.strokeRect(50, 60, 200, 100);
    ctx.fillRect(50, 170, 200, 100);

    
});