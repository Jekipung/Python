window.addEventListener('load',function() {
    let canvas = document.querySelector('#myCanvas');
    let ctx    = canvas.getContext('2d');

    let character = {
        x : 0,
        y : 0,
        width : 32,
        height : 32,
        key: { // 키 눌림 상태
            ArrowUp : false,
            ArrowDown : false,
            ArrowLeft : false,
            ArrowRight : false
        }
    };

    // 캐릭터를 그리는 함수
    function darwCharector() {
        ctx.strokeRect(
            character.x,
            character.y,
            character.width,
            character.height
        );
    }

    // 캐릭터를 지우는 함수
    function clearCharecter() {
        ctx.clearRect(
            character.x - 1,
            character.y - 1,
            character.width + 2,
            character.height + 2
        )
    }

    // 캐릭터를 움직이는 함수
    function moveCharacter(key) {
        if (character.key.ArrowLeft == true) {
            character.x -= 5;
        }
        if (character.key.ArrowRight == true) {
            character.x += 5;
        }
        if (character.key.ArrowUp == true) {
            character.y -= 5;
        }
        if (character.key.ArrowDown == true) {
            character.y += 5;
        }
    }

    // 충돌 체크 함수
    function checkCollision() {
        if (character.x < 0) character.x = 0;
        if (character.x > 608) character.x = 608;
        if (character.y < 0) character.y = 0;
        if (character.y > 368) character.y = 368;
    }

    // 초기의 한 번 그림
    darwCharector();
    

   // 키보드 다운 이벤트 핸들러 등록
    this.window.addEventListener('keydown', function(evt) {
        // console.log('[DOWN]' + evt. key);
        character.key[evt.key] = true;
    });

    // 키보드 업 이벤트 핸들러 등록
    this.window.addEventListener('keyup', function(evt) {
        // console.log('[ UP ]' + evt.key)
        character.key[evt.key] = false;
    });

    //게임 이벤트 루프 30FPS
    setInterval(function() { 
        clearCharecter();
        moveCharacter();
        checkCollision();
        darwCharector();
    }, 1000/60);
});