window.addEventListener('load', function() {
    let canvas = document.querySelector('#myCanvas');
    let ctx = canvas.getContext('2d');

    // 가로축 직선 그리기
    ctx.beginPath();
    ctx.moveTo(20, 20);
    ctx.lineTo(170, 20);

    //호 그리기
    let startAngle = -90 * Math.PI / 180;
    let endAngle = 0 * Math.PI / 180;
    ctx.arc(170, 40, 20, startAngle, endAngle, false);

    //세로축 직선 그리기
    ctx.lineTo(190, 140);

    ctx.stroke();
});