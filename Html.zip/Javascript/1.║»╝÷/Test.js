console.log('hello world')

/* Js의 변수 선언 키워드는 3개
var, let, const */

var x; // x라는 식별자로 변수 생성
console.log(x);
//왜? 값이 없으니까

x = 5; // 5를 x에 대입
console.log(x); // 5 출력

// 변수를 여러개 선언 및 초기화
var a = 1, b = 2, c = 3;

// 선언되지 않은 변수 참조: 참조 에러
// console.log(y);

// 호이스팅 - 변수 선언 끌어올림
/* JS는 실행시 먼저 실행을 위한 환경을
구성하기 때문에, 컨텍스트 내의 변수를
미리 준비한다.*/
console.log(t);
var t;

// let과 const
// let은 var와 다르게 호이스팅x
// console.log(k);
// 우리는 이제 let과 const만 사용한다.
let k = 10;
k = 6;
console.log(k);

/* const는 상수 선언
초기화와 동시에 값을 대입하고,
그 뒤로 변경 불가 */
const PI = 3.141592;
PI = 1.414;

